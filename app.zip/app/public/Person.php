<?php

namespace Tim;

class Person
{
     public $name = "Tim";
}
