<?php

// require_once './Person.php';
// use Tim\Person;

// $timPerson = new Person;
// echo $timPerson->name;

require_once 'vendor/autoload.php';

new Mii\Invoice\Kernel;
